package com.side_on;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SideOnApplication {

	public static void main(String[] args) {
		SpringApplication.run(SideOnApplication.class, args);
	}

}
